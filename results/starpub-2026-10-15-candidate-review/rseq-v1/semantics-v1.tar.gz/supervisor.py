from pathlib import Path
import contextlib,datetime,fcntl,hashlib,json,os,shutil,signal,subprocess,sys,time,traceback
root=Path('/root/harddind-rebuild');base=root/'rseq-semantics-owner-v1';base.mkdir(exist_ok=False)
shutil.copy2(__file__,base/'supervisor.py');shutil.copytree(root/'clock-query-owner-v1/repo',base/'repo')
sys.path.insert(0,str(base/'repo/scripts'))
import harddind
from guest_cleanup import cleanup_group,group_members
run=base/'run';run.mkdir()
for n in ['kernel-build.lock','client','network-backend','cache']:(run/n).symlink_to(root/n)
selftests=root/'rseq-owner-v1/selftests';kernel=root/'rseq-owner-v1/candidate-kernel';disk=root/'runtime-shares-v1.ext4';fixture=root/'cache/alpine-minirootfs-3.24.2-x86_64.tar.gz'
bins={n:selftests/n for n in ['basic_test','param_test','syscall_errors_test']}
shutil.copy2(root/'rseq-lifecycle-stage.c',base/'repo/src/rseq_lifecycle_probe.c');bins['rseq_lifecycle_probe']=base/'rseq_lifecycle_probe'
state={'status':'running','stage':'lock','commands':[],'tests':{},'full_acceptance':False,'performance_acceptance':False};env=dict(os.environ)
for k in ['LD_PRELOAD','HARDDIND_HR_CLOCK','DOCKER_HOST','DOCKER_CONTEXT','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH','GLIBC_TUNABLES']:env.pop(k,None)
env['PYTHONDONTWRITEBYTECODE']='1'
def save():
 p=base/'status.tmp';p.write_text(json.dumps(state,indent=2)+'\n');p.replace(base/'status.json')
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for x in iter(lambda:f.read(1048576),b''):h.update(x)
 return h.hexdigest()
@contextlib.contextmanager
def lock(path,ex):
 with path.open('a') as f:
  end=time.monotonic()+660
  while True:
   try:fcntl.flock(f,(fcntl.LOCK_EX if ex else fcntl.LOCK_SH)|fcntl.LOCK_NB);break
   except BlockingIOError:
    if time.monotonic()>end:raise TimeoutError('lock '+str(path))
    time.sleep(.2)
  try:yield
  finally:fcntl.flock(f,fcntl.LOCK_UN)
def call(label,cmd,timeout=90,data=None,required=True,extra_env=None):
 row={'label':label,'command':list(map(str,cmd)),'extra_env':extra_env or {}};state['commands'].append(row);save()
 with (base/(label+'.stdout')).open('xb') as out,(base/(label+'.stderr')).open('xb') as err:
  p=subprocess.Popen(row['command'],stdout=out,stderr=err,stdin=subprocess.PIPE if data else subprocess.DEVNULL,start_new_session=True,env={**env,**(extra_env or {})});row['pid']=p.pid;save();start=time.monotonic()
  try:p.communicate(data,timeout=timeout)
  except subprocess.TimeoutExpired:
   row['timeout']=True
   try:os.killpg(p.pid,signal.SIGKILL)
   except ProcessLookupError:pass
   p.communicate(timeout=15)
  finally:row['exit_code']=p.returncode;row['wall_seconds']=time.monotonic()-start;row['cleanup']=cleanup_group(p.pid);save()
 for s in ['stdout','stderr']:row[s+'_sha256']=sha(base/(label+'.'+s))
 save()
 if required:assert row['exit_code']==0 and not row.get('timeout') and row['cleanup']['clean_shutdown'],row
 return row
def cli(label,args,**kw):return call(label,[sys.executable,base/'repo/scripts/harddind.py',run,'rseqsem',*args],**kw)
def docker(label,args,**kw):return cli(label,['docker',*args],**kw)
cases=[('migration','basic_test',[],False),('lifecycle','rseq_lifecycle_probe',[],False),('increment','param_test',['-t','4','-r','1000','-T','i','-v'],False),('signal','param_test',['-t','4','-r','1000','-T','i','-4','10000','-7','-1','-m','1','-k','-v'],False),('yield','param_test',['-t','4','-r','1000','-T','s','-7','-1','-m','1','-y','-v'],False),('list','param_test',['-t','4','-r','1000','-T','l'],False),('buffer','param_test',['-t','4','-r','1000','-T','b'],False),('memcpy','param_test',['-t','4','-r','1000','-T','m'],False),('registration_errors','syscall_errors_test',[],True)]
def tests(where,container=None):
 for name,binary,args,disable in cases:
  label=where+'-'+name;state['stage']=label;save()
  if container:
   cmd=['exec']+(['-e','GLIBC_TUNABLES=glibc.pthread.rseq=0'] if disable else [])+[container,'/tests/'+binary,*args]
   row=docker(label,cmd,timeout=120,required=False)
  else:row=call(label,[bins[binary],*args],timeout=120,required=False,extra_env={'GLIBC_TUNABLES':'glibc.pthread.rseq=0'} if disable else None)
  output=(base/(label+'.stdout')).read_text();error=(base/(label+'.stderr')).read_text()
  good=row['exit_code']==0 and not row.get('timeout') and row['cleanup']['clean_shutdown'] and not any(x.startswith('not ok') for x in output.splitlines())
  if name=='lifecycle':
   events=[json.loads(x) for x in output.splitlines() if x.startswith('{')]
   good=good and {x['event'] for x in events}=={'four_thread_migration','fork_inheritance','exec_registration','parent_after_fork_exec'} and all(x['verified'] for x in events)
  state['tests'][label]={'status':('not_tested' if any('# skip' in x.lower() for x in output.splitlines()) else 'pass') if good else 'fail','exit_code':row['exit_code'],'timed_out':bool(row.get('timeout'))};save()
rc=1;instance=run/'instances/rseqsem';save()
try:
 os.sched_setaffinity(0,{0,1,2,3})
 with lock(root/'owner-experiment.lock',True):
  with lock(root/'kernel-build.lock',True):
   call('compile-lifecycle',['gcc','-O2','-Wall','-Wextra','-Werror','-static','-pthread',base/'repo/src/rseq_lifecycle_probe.c','-o',bins['rseq_lifecycle_probe']],60)
   state['inputs']={str(p):sha(p) for p in [kernel,disk,fixture,*bins.values(),base/'repo/src/rseq_lifecycle_probe.c']};save()
   tests('native-before')
  with lock(root/'kernel-build.lock',False):
   try:
    state['stage']='boot';save();cli('start',['start','--kernel',kernel,'--disk',disk,'--cpus','4','--memory','4G'],timeout=180)
    docker('import',['import','-','harddind-rseq-semantics:fixed'],data=fixture.read_bytes(),timeout=120)
    for suffix,cpus in [('all',None),('cpuset','2,3')]:
     name='rseq-tests-'+suffix
     docker(suffix+'-create',['create','--name',name,'--label','harddind-experiment=rseq-semantics-v1']+(['--cpuset-cpus',cpus] if cpus else [])+['harddind-rseq-semantics:fixed','sleep','600'])
     try:
      docker(suffix+'-start',['start',name]);docker(suffix+'-mkdir',['exec',name,'mkdir','/tests'])
      for binary,path in bins.items():docker(suffix+'-cp-'+binary,['cp',path,name+':/tests/'+binary])
      row=docker(suffix+'-digests',['exec',name,'sha256sum',*['/tests/'+n for n in bins]])
      actual={x.split()[1]:x.split()[0] for x in (base/(suffix+'-digests.stdout')).read_text().splitlines()};assert actual=={'/tests/'+n:state['inputs'][str(p)] for n,p in bins.items()}
      tests('guest-'+suffix,name)
     finally:docker(suffix+'-rm',['rm','-f',name],required=False)
   finally:
    if harddind.live(harddind.read_state(instance)):cli('stop',['stop'],timeout=100,required=False)
    st=harddind.read_state(instance);state['final_state']=st;save();assert st.get('phase')=='stopped' and st.get('guest_exit_code')==0 and not st.get('forced_shutdown',True)
  with lock(root/'kernel-build.lock',True):tests('native-after')
 assert len(state['tests'])==36
 rc=0 if all(x['status']=='pass' for x in state['tests'].values()) else 2
except BaseException:state['error']=traceback.format_exc()
finally:
 try:
  if harddind.live(harddind.read_state(instance)):cli('final-stop',['stop'],timeout=100,required=False)
  st=harddind.read_state(instance);state['final_state']=st;groups={x['pid'] for x in state['commands'] if 'pid' in x};groups.update(st[k] for k in ['guest_pid','network_pid','supervisor_pid'] if st.get(k))
  state['groups']={str(g):group_members(g) for g in sorted(groups)};state['groups_empty']=all(v==([],[]) for v in state['groups'].values());state['inputs_unchanged']=all(sha(p)==h for p,h in state.get('inputs',{}).items())
  if not state['groups_empty'] or not state['inputs_unchanged']:rc=1
 except BaseException:state['cleanup_error']=traceback.format_exc();rc=1
 state.update(status='finished',exit_code=rc,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
raise SystemExit(rc)
