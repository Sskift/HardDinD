from pathlib import Path
import datetime,difflib,fcntl,hashlib,json,os,shutil,signal,subprocess,sys,time,traceback
root=Path('/root/harddind-rebuild'); base=root/'rseq-owner-v1';base.mkdir(exist_ok=False)
shutil.copy2(__file__,base/'build.py')
sys.path.insert(0,str(root/'clock-query-owner-v1/repo/scripts'))
from guest_cleanup import cleanup_group
state={'status':'running','stage':'lock','commands':[],'full_acceptance':False,'runtime_verified':False}
def save():
 p=base/'build-status.tmp';p.write_text(json.dumps(state,indent=2)+'\n');p.replace(base/'build-status.json')
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def cmd(label,args,timeout=120):
 row={'label':label,'command':list(map(str,args))};state['commands'].append(row);save()
 with (base/(label+'.log')).open('xb') as log:
  p=subprocess.Popen(row['command'],stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True)
  row['pid']=p.pid;save();start=time.monotonic()
  try:row['exit_code']=p.wait(timeout)
  except subprocess.TimeoutExpired:
   row['timeout']=True
   try:os.killpg(p.pid,signal.SIGKILL)
   except ProcessLookupError:pass
   row['exit_code']=p.wait(15)
  row['wall_seconds']=time.monotonic()-start;row['cleanup']=cleanup_group(p.pid);save()
 assert row['exit_code']==0 and not row.get('timeout') and row['cleanup']['clean_shutdown'],row
rc=1;save()
try:
 os.sched_setaffinity(0,{0,1,2,3})
 with (root/'kernel-build.lock').open('a') as lock:
  until=time.monotonic()+660
  while True:
   try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);break
   except BlockingIOError:
    if time.monotonic()>until:raise TimeoutError('build lock wait')
    time.sleep(.2)
  archive=root/'cache/linux-7.2.10.tar.xz';assert sha(archive)=='2feaa70453e91f541be6a5c9078d8168e081af45a3d9718054850538cff2ebf3'
  manifest=json.loads((root/'cpu-cpuset-owner-v1/kernel-patches.json').read_text())
  shutil.copy2(root/'cpu-cpuset-owner-v1/kernel-patches.json',base/'baseline-patches.json')
  shutil.copy2(root/'cpu-cpuset-owner-v1/kernel.config',base/'baseline.config')
  patches=base/'baseline-patches';patches.mkdir()
  for name,digest in manifest['patches'].items():
   matches=[p for p in [root/'kernel/patches'/name,root/'kernel/experiments'/name] if p.exists() and sha(p)==digest]
   assert len(matches)==1,(name,'no exact patch source');shutil.copy2(matches[0],patches/name)
  state['stage']='extract';save();cmd('extract',['tar','-xJf',archive,'-C',base],180)
  source=base/'linux-7.2.10'
  for i,name in enumerate(manifest['patches']):cmd('patch-'+str(i),['patch','--batch','--forward','-p1','-d',source,'-i',patches/name])
  state['baseline_files_verified']=all(sha(source/name)==h for name,h in manifest['files'].items());assert state['baseline_files_verified'];save()
  originals={}
  def replace(rel,old,new):
   p=source/rel;s=p.read_text();originals.setdefault(rel,s);assert s.count(old)==1,(rel,old);p.write_text(s.replace(old,new))
  replace('arch/um/Kconfig','config MMU\n','config UML_X86_RSEQ\n\tbool "Experimental x86-64 restartable sequences"\n\tdepends on X86_64\n\tselect HAVE_RSEQ\n\tdefault n\n\thelp\n\t  Enable the generic rseq ABI for x86-64 UML tasks. CPU IDs come\n\t  from the guest scheduler; scheduling and signal return use the\n\t  generic rseq fixups. This experimental option is off by default\n\t  pending migration, signal, fork/exec and workload validation.\n\nconfig MMU\n')
  replace('arch/um/include/asm/ptrace-generic.h','#define instruction_pointer(regs) PT_REGS_IP(regs)\n','#define instruction_pointer(regs) PT_REGS_IP(regs)\n\nstatic inline void instruction_pointer_set(struct pt_regs *regs,\n\t\t\t\t   unsigned long val)\n{\n\tPT_REGS_IP(regs) = val;\n}\n')
  replace('arch/um/kernel/signal.c','#include <linux/ptrace.h>\n','#include <linux/ptrace.h>\n#include <linux/rseq.h>\n')
  replace('arch/um/kernel/signal.c','\tsp = PT_REGS_SP(regs);\n','\t/* Fix up an interrupted rseq before the signal frame saves its IP. */\n\trseq_signal_deliver(ksig, regs);\n\n\tsp = PT_REGS_SP(regs);\n')
  replace('arch/um/kernel/skas/syscall.c','#include <linux/ptrace.h>\n','#include <linux/ptrace.h>\n#include <linux/rseq.h>\n')
  replace('arch/um/kernel/skas/syscall.c','out:\n\tsyscall_trace_leave(regs);\n','out:\n\tsyscall_trace_leave(regs);\n\t/* Generic debug validation; the normal resume hook handles ID updates. */\n\trseq_syscall(regs);\n')
  patch=''.join(''.join(difflib.unified_diff(old.splitlines(True),(source/rel).read_text().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)) for rel,old in originals.items())
  (base/'0001-EXPERIMENTAL-um-x86-rseq-v1.patch').write_text(patch)
  state['changed_sources']={rel:sha(source/rel) for rel in originals};save()
  out=base/'build';out.mkdir();shutil.copy2(base/'baseline.config',out/'.config')
  cmd('set-config',[source/'scripts/config','--file',out/'.config','--enable','UML_X86_RSEQ','--enable','RSEQ','--enable','DEBUG_RSEQ'])
  cmd('olddefconfig',['make','-C',source,'O='+str(out),'ARCH=um','olddefconfig'],120)
  def cfg(p):return {s.split('=')[0]:s.split('=',1)[1] for s in p.read_text().splitlines() if s.startswith('CONFIG_')}
  before=cfg(base/'baseline.config');after=cfg(out/'.config');state['config_changes']={k:[before.get(k),v] for k,v in after.items() if before.get(k)!=v};state['lost_config']={k:v for k,v in before.items() if after.get(k)!=v}
  assert not state['lost_config'],state['lost_config']
  assert after.get('CONFIG_UML_X86_RSEQ')==after.get('CONFIG_HAVE_RSEQ')==after.get('CONFIG_RSEQ')=='y'
  assert after.get('CONFIG_GENERIC_ENTRY')!='y' and after.get('CONFIG_RSEQ_SLICE_EXTENSION')!='y'
  shutil.copy2(out/'.config',base/'candidate.config');save()
  state['stage']='kernel-build';save();cmd('kernel-build',['make','-C',source,'O='+str(out),'ARCH=um','-j4','linux'],1800)
  cmd('stub-relocations',['python3',root/'clock-query-owner-v1/repo/scripts/check-stub-relocations.py',out/'arch/um/kernel/skas/stub.o'])
  shutil.copy2(out/'linux',base/'candidate-kernel')
  state['artifacts']={str(p.relative_to(base)):sha(p) for p in [base/'baseline.config',base/'candidate.config',base/'candidate-kernel',base/'0001-EXPERIMENTAL-um-x86-rseq-v1.patch']}
  rc=0
except BaseException:state['error']=traceback.format_exc()
finally:
 state.update(status='finished',exit_code=rc,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
sys.exit(rc)
