from pathlib import Path
import contextlib, datetime, fcntl, hashlib, json, os, shutil, signal, subprocess, sys, time, traceback
sys.dont_write_bytecode = True
base = Path('/root/harddind-rebuild/clock-query-owner-v1')
root = base.parent
base.mkdir(exist_ok=False)
shutil.copytree(root/'workflow-owner-v5/repo', base/'repo')
shutil.copy2(root/'clock-query-probe-stage.c', base/'repo/src/clock_query_probe.c')
shutil.copy2(__file__, base/'supervisor.py')
sys.path.insert(0, str(base/'repo/scripts'))
import harddind
from guest_cleanup import cleanup_group, group_members
run = base/'run'; run.mkdir()
for name in ['kernel-build.lock', 'network-backend', 'client', 'cache']: (run/name).symlink_to(root/name)
instance = run/'instances/query1'
probe = base/'clock-query-probe'
source = base/'repo/src/clock_query_probe.c'
kernel = root/'cpu-clock-work-owner-v1/baseline-kernel'
disk = root/'runtime-shares-v1.ext4'
fixture = root/'cache/alpine-minirootfs-3.24.2-x86_64.tar.gz'
state = {'status':'running','commands':[],'cells':{},'full_acceptance':False,'performance_acceptance':False,'scope':'Clock/getcpu path diagnostic only; original cpu_limit_probe unchanged','affinity':[0,1,2,3]}
def save():
 p=base/'status.tmp'; p.write_text(json.dumps(state,indent=2)+'\n'); p.replace(base/'status.json')
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for x in iter(lambda:f.read(1048576),b''): h.update(x)
 return h.hexdigest()
@contextlib.contextmanager
def locked(path, exclusive):
 with path.open('a') as f:
  until=time.monotonic()+660
  while True:
   try: fcntl.flock(f, (fcntl.LOCK_EX if exclusive else fcntl.LOCK_SH)|fcntl.LOCK_NB); break
   except BlockingIOError:
    if time.monotonic()>until: raise TimeoutError('lock deadline '+str(path))
    time.sleep(.2)
  try: yield
  finally: fcntl.flock(f,fcntl.LOCK_UN)
def call(label,cmd,timeout=90,data=None,required=True):
 row={'label':label,'command':list(map(str,cmd)),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()};state['commands'].append(row);save()
 with (base/(label+'.stdout')).open('xb') as out,(base/(label+'.stderr')).open('xb') as err:
  p=subprocess.Popen(row['command'],stdin=subprocess.PIPE if data is not None else subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True,env=env)
  row['pid']=p.pid;save();start=time.monotonic()
  try: p.communicate(data,timeout=timeout)
  except subprocess.TimeoutExpired:
   row['timeout']=True
   try: os.killpg(p.pid,signal.SIGKILL)
   except ProcessLookupError: pass
   p.communicate(timeout=15)
  finally:
   row['exit_code']=p.returncode;row['wall_seconds']=time.monotonic()-start;row['cleanup']=cleanup_group(p.pid);save()
 row['stdout_sha256']=sha(base/(label+'.stdout'));row['stderr_sha256']=sha(base/(label+'.stderr'));save()
 if required: assert row['exit_code']==0 and not row.get('timeout') and row['cleanup']['clean_shutdown'],row
 return (base/(label+'.stdout')).read_text()
def cli(label,args,**kw): return call(label,[sys.executable,base/'repo/scripts/harddind.py',run,'query1',*args],**kw)
def docker(label,args,**kw):return cli(label,['docker',*args],**kw)
def analyze(label,threads,cpus):
 rows=[json.loads(x) for x in (base/(label+'.stdout')).read_text().splitlines() if x.startswith('{')]
 info=[x for x in rows if x.get('event')=='info']; samples=[x for x in rows if x.get('event')=='sample']; end=[x for x in rows if x.get('event')=='complete']
 assert len(info)==1 and len(end)==1 and end[0]['verified'] is True
 assert len(samples)==threads*5*3
 keys={(x['mode'],x['repeat'],x['thread']) for x in samples};assert len(keys)==len(samples)
 assert {x['mode'] for x in samples}=={'libc_clock','syscall_clock','libc_getcpu','syscall_getcpu','libc_clock_getcpu'}
 for x in samples:
  assert x['verified'] is True and x['errno']==x['bad_cpu']==x['backwards']==0 and x['completed']==x['iterations']==20000 and x['end_raw_ns']>x['start_raw_ns']
  assert x['allowed_cpus']==cpus
 state['cells'][label]={'info':info[0],'samples':samples,'checked':True};save()
rc=1;env=dict(os.environ)
for k in ['LD_PRELOAD','HARDDIND_HR_CLOCK','DOCKER_HOST','DOCKER_CONTEXT','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH']:env.pop(k,None)
env['PYTHONDONTWRITEBYTECODE']='1'
save()
try:
 os.sched_setaffinity(0,{0,1,2,3})
 state['inputs']={str(p):sha(p) for p in [kernel,disk,fixture,source,base/'repo/scripts/harddind.py',base/'repo/scripts/guest_cleanup.py']};save()
 assert state['inputs'][str(kernel)]=='fb5e56e48240f96a997aa0f1d234992f128d23dd428eb8256dfccccc4d217fca'
 assert state['inputs'][str(fixture)]=='c5ca053cfe1d85c5b96dff8b9bc57045f7f184a30ffb6b65776409ca90388677'
 with locked(root/'owner-experiment.lock',True):
  state['stage']='compile';save()
  with locked(root/'kernel-build.lock',True):
   call('compiler-version',['gcc','--version'])
   call('compile',['gcc','-O2','-Wall','-Wextra','-Werror','-static','-pthread',source,'-o',probe],60)
   state['probe_sha256']=sha(probe);state['inputs'][str(probe)]=state['probe_sha256'];save()
   call('disassembly',['objdump','-d','--disassemble=sched_getcpu',probe],30)
   for n in [1,4]:
    label='native-before-'+str(n);state['stage']=label;save();call(label,[probe,n,20000,3],60);analyze(label,n,[0,1,2,3])
  with locked(root/'kernel-build.lock',False):
   try:
    state['stage']='guest-start';save();cli('start',['start','--kernel',kernel,'--disk',disk,'--cpus','4','--memory','4G'],timeout=180)
    docker('import',['import','-','harddind-query:fixed'],data=fixture.read_bytes(),timeout=120)
    for n,cpus in [(1,None),(4,None),(4,'2,3')]:
     label='guest-'+str(n)+('-cpuset' if cpus else '');name='query-'+label
     state['stage']=label;save();args=['create','--name',name,'--label','harddind-experiment=clock-query-v1']
     if cpus:args+=['--cpuset-cpus',cpus]
     args+=['harddind-query:fixed','/bin/sh','-c','sha256sum /clock-query-probe && exec /clock-query-probe '+str(n)+' 20000 3']
     docker(label+'-create',args)
     try:
      docker(label+'-cp',['cp',probe,name+':/clock-query-probe'])
      output=docker(label,['start','-a',name],timeout=240)
      assert output.splitlines()[0].split()[0]==state['probe_sha256']
      exit_code=docker(label+'-exit',['inspect','--format','{{.State.ExitCode}}',name]);assert exit_code.strip()=='0'
      analyze(label,n,[2,3] if cpus else [0,1,2,3])
     finally: docker(label+'-rm',['rm','-f',name],required=False)
   finally:
    if harddind.live(harddind.read_state(instance)):cli('stop',['stop'],timeout=100,required=False)
    st=harddind.read_state(instance);state['final_state']=st;save()
    assert st.get('phase')=='stopped' and st.get('guest_exit_code')==0 and not st.get('forced_shutdown',True)
  with locked(root/'kernel-build.lock',True):
   for n in [1,4]:
    label='native-after-'+str(n);state['stage']=label;save();call(label,[probe,n,20000,3],60);analyze(label,n,[0,1,2,3])
 rc=0
except BaseException:state['error']=traceback.format_exc()
finally:
 try:
  if harddind.live(harddind.read_state(instance)):cli('final-stop',['stop'],timeout=100,required=False)
  st=harddind.read_state(instance);state['final_state']=st
  groups={x['pid'] for x in state['commands'] if 'pid' in x}
  groups.update(st[k] for k in ['guest_pid','network_pid','supervisor_pid'] if st.get(k))
  state['groups']={str(g):group_members(g) for g in sorted(groups)}
  state['groups_empty']=all(v==([],[]) for v in state['groups'].values())
  state['inputs_unchanged']=all(sha(p)==h for p,h in state.get('inputs',{}).items())
  if not state['groups_empty'] or not state['inputs_unchanged']:rc=1
 except BaseException:state['cleanup_error']=traceback.format_exc();rc=1
 state.update(status='finished',exit_code=rc,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
sys.exit(rc)
