from pathlib import Path
import subprocess,json,time,datetime
b=Path(__file__).resolve().parent;prior=b.parent/'workflow-owner-v2'
r={'status':'waiting-for-batch'}
def save():(b/'followup-status.json').write_text(json.dumps(r,indent=2)+'\n')
save();end=time.monotonic()+1800
while True:
    s=json.loads((prior/'batch-status.json').read_text())
    if s['status']=='finished':break
    if time.monotonic()>end:raise TimeoutError('batch wait exceeded 1800 seconds')
    time.sleep(2)
assert not s.get('error'),s
for shard in s['cells']:
    c=json.loads((prior/('wf2-'+shard+'-status.json')).read_text());assert c['groups_empty'],c
r['status']='testing';save()
with (b/'unit.stdout').open('xb') as so,(b/'unit.stderr').open('xb') as se:
    test=subprocess.run(['python3','-B','-m','unittest','discover','-s','tests','-p','test_workflow*.py'],cwd=b/'repo',stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=30)
r['unit_exit']=test.returncode;save()
if test.returncode==0:
    r['status']='build-workflow';save()
    with (b/'wf3-build-supervisor.log').open('x') as log:
        p=subprocess.Popen(['python3',str(b/'supervisor.py'),'build'],stdin=subprocess.DEVNULL,stdout=log,stderr=log)
        r['pid']=p.pid;save();r['runner_exit']=p.wait()
r.update(status='finished',finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
