from pathlib import Path
import hashlib,json
b=Path('/root/harddind-rebuild/workflow-owner-v3');p=b/'repo/scripts/run-workflow-timing.py';s=p.read_text()
assert not (b/'run').exists(), 'do not mutate an executing candidate'
s=s.replace("'warm_id_equal'", "'warm_content_equal'")
a=s.index('\ndef object_missing')
s=s[:a]+'''\ndef build_image_content(text):
    """Compare executed image data; a new attestation may change the index ID."""
    info = json.loads(text)
    layers = info.get('RootFS', {}).get('Layers')
    if (not isinstance(layers, list) or not layers
            or not all(isinstance(v, str) and re.fullmatch(r'sha256:[0-9a-f]{64}', v) for v in layers)
            or not isinstance(info.get('Config'), dict)
            or not info.get('Os') or not info.get('Architecture')):
        raise ValueError('missing image layers or execution configuration')
    return {key: info.get(key) for key in ('RootFS', 'Config', 'Os', 'Architecture', 'Variant')}

'''+s[a:]
a=s.index("    ctx.check('warm_content_equal', warm_id == cold_id")
z=s.index("    cold_run =",a)
s=s[:a]+'''    cold_info = ctx.run('content_cold', ['image', 'inspect', '-f', '{{json .}}', cold_tag], need_output=True)['stdout']
    warm_info = ctx.run('content_warm', ['image', 'inspect', '-f', '{{json .}}', warm_tag], need_output=True)['stdout']
    cold_content = build_image_content(cold_info)
    warm_content = build_image_content(warm_info)
    ctx.obs['build_image_content'] = {'cold': cold_content, 'warm': warm_content,
                                       'cold_id': cold_id, 'warm_id': warm_id}
    ctx.check('warm_content_equal', bool(re.fullmatch(r'[0-9a-f]{64}', warm_id))
              and cold_content == warm_content, 'RootFS, Config, OS, architecture and variant comparison')
'''+s[z:]
s=s.replace("'build': ('build_cold', 'build_warm', 'run_cold'", "'build': ('build_cold', 'build_warm', 'content_cold', 'content_warm', 'run_cold'")
compile(s,str(p),'exec');p.write_text(s)
p=b/'repo/tests/test_workflow_transport.py';s=p.read_text()
needle="    def test_real_lowercase_removal_error(self):"
new='''    def test_build_content_compares_layers_and_runtime_config(self):
        image = {'Id': 'sha256:'+'1'*64, 'RootFS': {'Type':'layers','Layers':['sha256:'+'a'*64]},
                 'Config': {'Cmd':['cat','/wf/payload.sha']}, 'Os':'linux', 'Architecture':'amd64'}
        first = wf.build_image_content(json.dumps(image))
        image['Id'] = 'sha256:'+'2'*64
        image['Metadata'] = {'attestation':'new-build'}
        self.assertEqual(first, wf.build_image_content(json.dumps(image)))
        image['RootFS']['Layers'][0] = 'sha256:'+'b'*64
        self.assertNotEqual(first, wf.build_image_content(json.dumps(image)))
        image['RootFS']['Layers'][0] = 'sha256:'+'a'*64
        image['Config']['Cmd'] = ['true']
        self.assertNotEqual(first, wf.build_image_content(json.dumps(image)))
        del image['RootFS']
        with self.assertRaises(ValueError): wf.build_image_content(json.dumps(image))

'''
s=s.replace(needle,new+needle);p.write_text(s)
print('BuildKit identity invariant repaired; missing and changed layers/config remain failures')
