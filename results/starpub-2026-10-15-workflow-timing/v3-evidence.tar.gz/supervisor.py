from pathlib import Path
import datetime,fcntl,json,os,signal,subprocess,sys,time,traceback
b=Path(__file__).resolve().parent;w=b.parent
sys.dont_write_bytecode=True
sys.path.insert(0,str(b/'repo/scripts'))
import harddind
from guest_cleanup import cleanup_group,group_members
run=b/'run';run.mkdir(exist_ok=True)
for name in ['network-backend','client','kernel-build.lock','cache']:
    if not (run/name).exists(): (run/name).symlink_to(w/name)
shard=sys.argv[1]
assert shard in ['lifecycle','image','volume','build','net']
name='wf3-'+shard
status=b/(name+'-status.json');assert not status.exists()
r={'status':'running','shard':shard,'name':name,'full_acceptance':False,'performance_acceptance':False,'affinity':[0,1,2,3]}
def save(): status.write_text(json.dumps(r,indent=2)+'\n')
base=[sys.executable,str(b/'repo/scripts/harddind.py'),str(run),name]
rc=1
try:
    os.sched_setaffinity(0,{0,1,2,3})
    with (w/'owner-experiment.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        r['command']=[sys.executable,str(b/'repo/scripts/run-workflow-timing.py'),str(run),'--kernel',str(w/'cpu-clock-work-owner-v1/baseline-kernel'),'--disk',str(w/'runtime-shares-v1.ext4'),'--name',name,'--shards',shard,'--reps','3','--cpus','4','--workload-budget','120','--start-timeout','100','--stop-timeout','75','--command-timeout','20','--build-timeout','60']
        r['started_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
        with (b/(name+'.stdout')).open('xb') as so,(b/(name+'.stderr')).open('xb') as se:
            p=subprocess.Popen(r['command'],stdin=subprocess.DEVNULL,stdout=so,stderr=se,start_new_session=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
            r['pid']=p.pid;save()
            try: r['runner_exit']=p.wait(300)
            except subprocess.TimeoutExpired:
                r['timeout']=True;os.killpg(p.pid,signal.SIGTERM)
                try:r['runner_exit']=p.wait(90)
                except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);r['runner_exit']=p.wait(10)
            r['cleanup']=cleanup_group(p.pid)
        st=harddind.read_state(run/'instances'/name)
        if harddind.live(st):
            q=subprocess.run(base+['stop'],stdin=subprocess.DEVNULL,capture_output=True,timeout=90)
            r['final_stop']={'exit_code':q.returncode,'stdout':q.stdout.decode(),'stderr':q.stderr.decode()}
            st=harddind.read_state(run/'instances'/name)
        r['final_state']=st
        groups={p.pid}|{st[k] for k in ['supervisor_pid','guest_pid','network_pid'] if st.get(k)}
        reportfile=run/'results'/(name+'.json')
        if reportfile.is_file():
            report=json.loads(reportfile.read_text());r['subset_passed']=report['subset_passed'];r['problems']=report['problems'];r['summary']=report['summary']
            components=report.get('fixture_components',[])+report.get('leftover_components',[])
            for data in report['workflows'].values():
                for obs in data['observations']:components+=obs['components']
            groups.update(c['pid'] for c in components if c.get('pid'))
            for c in [report['setup'].get('boot',{}),report['instance_cleanup'].get('stop_command',{})]:
                if c.get('pid'):groups.add(c['pid'])
        r['groups']={str(g):group_members(g) for g in sorted(groups)}
        r['groups_empty']=all(v==([],[]) for v in r['groups'].values())
        rc=0 if r.get('subset_passed') and r['groups_empty'] and r['runner_exit']==0 and not r.get('timeout') else 1
except BaseException:r['error']=traceback.format_exc()
finally:r.update(status='finished',exit_code=rc,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
sys.exit(rc)
