from pathlib import Path
import shutil
w=Path('/root/harddind-rebuild');old=w/'workflow-owner-v3';b=w/'workflow-owner-v4';b.mkdir(exist_ok=False)
shutil.copytree(old/'repo',b/'repo')
(b/'supervisor.py').write_text((old/'supervisor.py').read_text().replace("name='wf3-'+shard","name='wf4-'+shard"))
p=b/'repo/scripts/run-workflow-timing.py';s=p.read_text();a=s.index("    server_script =",s.index('def workflow_net'));z=s.index("    ctx.run('server_start'",a)
s=s[:a]+'''    server_script = ('mkdir -p /www && printf %s ' + shlex.quote(token + '\\n')
                     + ' >/www/index.html && '
                     + 'bytes=$(wc -c < /www/index.html); '
                     + "{ printf 'HTTP/1.1 200 OK\\\\r\\\\nContent-Length: %s\\\\r\\\\nConnection: close\\\\r\\\\n\\\\r\\\\n' \\\"$bytes\\\"; "
                     + 'cat /www/index.html; } >/www/response; '
                     + 'exec nc -lk -p 8080 -e cat /www/response')
'''+s[z:]
s=s.replace("    expected_ip = ctx.run('server_ip'", "    ctx.run('server_logs', ['logs', srv])\n    running = ctx.run('server_running', ['inspect', '-f', '{{.State.Running}}', srv], need_output=True)['stdout'].strip()\n    ctx.check('server_running', running == 'true', running)\n    expected_ip = ctx.run('server_ip'")
s=s.replace("'net': ('dns_resolved'", "'net': ('server_running', 'dns_resolved'")
s=s.replace("'net': ('network_create', 'server_start', 'dns_try0'", "'net': ('network_create', 'server_start', 'server_running', 'server_logs', 'dns_try0'")
s=s.replace("http://%s:8080/ 2>/dev/null", "http://%s:8080/")
compile(s,str(p),'exec');p.write_text(s)
print('network fixture prepared with existing pinned busybox nc HTTP protocol')
