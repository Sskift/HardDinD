from pathlib import Path
import subprocess,json,time,tarfile,hashlib,sys
b=Path(__file__).resolve().parent;w=b.parent
sys.dont_write_bytecode=True;sys.path.insert(0,str(b/'repo/scripts'))
from guest_cleanup import cleanup_group
end=time.monotonic()+600
while True:
    s=json.loads((b/'wf5-net-status.json').read_text())
    if s['status']=='finished':break
    if time.monotonic()>end:raise TimeoutError('network wait')
    time.sleep(2)
assert s['groups_empty']
folder=b/'fixture-check';folder.mkdir(exist_ok=False)
rootfs=w/'cache/alpine-minirootfs-3.24.2-x86_64.tar.gz'
with tarfile.open(rootfs) as t:
    names=[n for n in t.getnames() if n.lstrip('./')=='bin/busybox'];assert len(names)==1
    data=t.extractfile(names[0]).read()
p=folder/'busybox';p.write_bytes(data);p.chmod(0o500)
r={'busybox_sha256':hashlib.sha256(data).hexdigest(),'commands':[],'note':'Use the correct argv[0] basename; earlier renamed binary diagnosed its own dispatch name, not applet availability.'}
for name,args in [('applets',['--list']),('httpd',['httpd','--help']),('nc',['nc','--help'])]:
    cmd=[str(w/'client/ld-musl-x86_64.so.1'),str(p),*args]
    proc=subprocess.Popen(cmd,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
    out,err=proc.communicate(timeout=10)
    r['commands'].append({'name':name,'argv':cmd,'exit_code':proc.returncode,'stdout':out.decode(),'stderr':err.decode(),'cleanup':cleanup_group(proc.pid)})
apps=r['commands'][0]
r['httpd_available']='httpd' in apps['stdout'].splitlines() if apps['exit_code']==0 else None
r['nc_available']='nc' in apps['stdout'].splitlines() if apps['exit_code']==0 else None
(b/'fixture-check.json').write_text(json.dumps(r,indent=2)+'\n')
subprocess.run(['python3',str(b/'export.py')],check=True,timeout=180)
