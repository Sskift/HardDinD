from pathlib import Path
import datetime,gzip,hashlib,io,json,sys,tarfile
w=Path('/root/harddind-rebuild')
out=w/'evidence-export/workflow-timing';out.mkdir(exist_ok=True)
sys.dont_write_bytecode=True;sys.path.insert(0,str(w/'workflow-owner-v4/repo/scripts'))
from guest_cleanup import group_members
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
summary={}
for version in [1,2,3,4,5]:
 existing=out/('v%d-evidence.tar.gz'%version)
 if existing.exists():
  with tarfile.open(existing) as t:
   entries={m.name:t.extractfile(m).read() for m in t.getmembers() if m.isfile()}
  manifest=json.loads(entries.pop('manifest.json'))
  assert set(entries)==set(manifest)
  assert all(hashlib.sha256(data).hexdigest()==manifest[name] for name,data in entries.items())
  audit=json.loads((out/('v%d-audit.json'%version)).read_text())
  assert audit['groups_empty']
  summary[str(version)]={'reports':list(audit['reports']),'groups':len(audit['groups']),'archive_sha256':sha(existing)}
  print('verified completed archive',version,flush=True)
  continue
 b=w/('workflow-owner-v'+str(version));prefix='wf'+str(version)+'-'
 statuses=sorted(b.glob(prefix+'*-status.json'));assert statuses
 members={};artifacts={};reports={}
 for p in statuses:
  s=json.loads(p.read_text());assert s['status']=='finished' and s['groups_empty'],p
  members.update({g:group_members(int(g)) for g in s['groups']})
  report=json.loads((b/'run/results'/(s['name']+'.json')).read_text())
  assert report['inputs_unchanged']
  for path,digest in report['input_hashes_after'].items():assert sha(Path(path))==digest,path
  for v in report['workflows'].values():
   for obs in v['observations']:
    for a in obs.get('artifacts',{}).values():
     path=Path(a['path']);assert sha(path)==a['sha256'],path
     artifacts[str(path)]={'sha256':sha(path),'bytes':path.stat().st_size}
  reports[s['name']]={'subset_passed':report['subset_passed'],'summary':report['summary'],
                      'problems':report['problems'],'total_wall_seconds':report['total_wall_seconds']}
 audit={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'groups':members,
        'groups_empty':all(v==([],[]) for v in members.values()),'input_hashes_unchanged':True,
        'binary_artifacts':artifacts,'reports':reports,'full_acceptance':False,'performance_acceptance':False}
 assert audit['groups_empty']
 (out/('v%d-audit.json'%version)).write_text(json.dumps(audit,indent=2)+'\n')
 files=[]
 for p in b.iterdir():
  if p.is_file() and p.suffix in ['.json','.py','.stdout','.stderr','.log']:files.append(p)
 for p in (b/'repo/scripts').iterdir():
  if p.name in ['run-workflow-timing.py','analyze-workflow-timing.py','harddind.py','guest_cleanup.py','port_driver.py']:files.append(p)
 for p in (b/'repo/tests').glob('test_workflow*.py'):files.append(p)
 files.append(b/'repo/sources.lock.json')
 for p in (b/'run/results').rglob('*'):
  if p.is_file() and p.suffix in ['.json','.log','.stdout','.stderr']:files.append(p)
 for p in (b/'run/instances').rglob('*'):
  if p.is_file() and p.suffix in ['.json','.log'] and 'docker-config' not in p.parts:files.append(p)
 manifest={}
 with tarfile.open(out/('v%d-evidence.tar.gz'%version),'w:gz') as t:
  for p in sorted(set(files)):
   name=str(p.relative_to(b));manifest[name]=sha(p);t.add(p,arcname=name,recursive=False)
  data=json.dumps(manifest,indent=2).encode()+b'\n';info=tarfile.TarInfo('manifest.json');info.size=len(data);t.addfile(info,io.BytesIO(data))
 summary[str(version)]={'reports':list(reports),'groups':len(members),'archive_sha256':sha(out/('v%d-evidence.tar.gz'%version))}
(out/'export.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
