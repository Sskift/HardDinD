from pathlib import Path
import subprocess,json,datetime
b=Path(__file__).resolve().parent
r={'status':'running','cells':{}}
def save():(b/'batch-status.json').write_text(json.dumps(r,indent=2)+'\n')
save()
for shard in ['lifecycle','image','volume','build','net']:
    r['stage']=shard;save()
    with (b/('wf2-'+shard+'-supervisor.log')).open('x') as log:
        p=subprocess.Popen(['python3',str(b/'supervisor.py'),shard],stdin=subprocess.DEVNULL,stdout=log,stderr=log)
        r['cells'][shard]={'pid':p.pid};save()
        rc=p.wait()
    r['cells'][shard]['exit_code']=rc;save()
    s=json.loads((b/('wf2-'+shard+'-status.json')).read_text())
    if not s.get('groups_empty'):
        r['error']='process cleanup incomplete; stop scheduling';break
r.update(status='finished',finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
