from pathlib import Path
import shutil
w=Path('/root/harddind-rebuild');old=w/'workflow-owner-v2';b=w/'workflow-owner-v3';b.mkdir(exist_ok=False)
shutil.copytree(old/'repo',b/'repo')
(b/'supervisor.py').write_text((old/'supervisor.py').read_text().replace("name='wf2-'+shard","name='wf3-'+shard"))
p=b/'repo/scripts/run-workflow-timing.py';s=p.read_text()
s=s.replace("expect=(0,), tolerated=False, overlaps=()):", "expect=(0,), tolerated=False, overlaps=(), seconds=None):")
s=s.replace("'timed_out': timed_out, 'seconds': time.monotonic() - started,", "'timed_out': timed_out, 'seconds': time.monotonic() - started if seconds is None else seconds,")
s=s.replace("expect=expect, tolerated=tolerate, overlaps=overlaps)\n        comp['seconds'] = elapsed", "expect=expect, tolerated=tolerate, overlaps=overlaps, seconds=elapsed)")
s=s.replace("        return self._popen(cmd), time.monotonic()", "        started = time.monotonic()\n        proc = self._popen(cmd)\n        proc._harddind_started = started\n        return proc, started")
s=s.replace("        finally:\n            if proc.poll() is None:\n                self._kill(proc)\n            proc._harddind_cleanup", "        finally:\n            proc._harddind_seconds = time.monotonic() - proc._harddind_started\n            if proc.poll() is None:\n                self._kill(proc)\n            proc._harddind_cleanup")
s=s.replace("overlaps=('stop',))", "overlaps=('stop',), seconds=waiter._harddind_seconds)")
s=s.replace("% (rc, timed_out, time.monotonic() - started)", "% (rc, timed_out, elapsed)")
s=s.replace("*ctx.labels('build'), cold_tag]", "*ctx.labels('build'), cold_tag, 'sha256sum', '/wf/payload.bin']")
s=s.replace("*ctx.labels('build'), warm_tag]", "*ctx.labels('build'), warm_tag, 'sha256sum', '/wf/payload.bin']")
s=s.replace("and not state.get('forced_shutdown')), ", "and not state.get('forced_shutdown')),")
compile(s,str(p),'exec');p.write_text(s)
p=b/'repo/tests/test_workflow_transport.py';s=p.read_text()
s=s.replace("            client = wf.Client([sys.executable, str(fake), 'docker'], io.StringIO(),", "            log = io.StringIO()\n            client = wf.Client([sys.executable, str(fake), 'docker'], log,")
s=s.replace("            self.assertTrue(c['cleanup']['clean_shutdown'])\n            self.assertEqual(wf.group_members", "            self.assertIn('seconds=%.6f' % c['seconds'], log.getvalue())\n            self.assertTrue(c['cleanup']['clean_shutdown'])\n            self.assertEqual(wf.group_members",1)
needle="    def test_real_lowercase_removal_error(self):"
new='''    def test_background_wait_records_launch_and_reap(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            log = io.StringIO()
            client = wf.Client([sys.executable, '-c', "print('137')"], log, time.monotonic()+5, {'command': 3}, root)
            p, started = client.spawn([])
            rc, out, err, timeout = client.reap_spawned(p)
            c = client.component('wait', [], rc, out, err, started, timeout, seconds=p._harddind_seconds)
            self.assertEqual(rc, 0)
            self.assertEqual(out, b'137\\n')
            self.assertFalse(timeout)
            self.assertTrue(p._harddind_cleanup['clean_shutdown'])
            self.assertGreater(c['seconds'], 0)
            self.assertIn('seconds=%.6f' % c['seconds'], log.getvalue())

'''
s=s.replace(needle,new+needle);p.write_text(s)
print('v3 source prepared; no tests or workload launched')
