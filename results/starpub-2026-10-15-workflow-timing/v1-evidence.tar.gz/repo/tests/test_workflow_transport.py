import importlib.util
import io
import json
from pathlib import Path
import sys
import tempfile
import time
import unittest

spec = importlib.util.spec_from_file_location('workflow', Path(__file__).resolve().parents[1] / 'scripts/run-workflow-timing.py')
wf = importlib.util.module_from_spec(spec)
spec.loader.exec_module(wf)

class TransportTests(unittest.TestCase):
    def test_real_stdin_binary_and_argv(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            fake = root / 'cli.py'
            fake.write_text("import sys,hashlib,json; data=sys.stdin.buffer.read(); print(json.dumps({'args':sys.argv[1:],'sha':hashlib.sha256(data).hexdigest(),'bytes':len(data)}))")
            client = wf.Client([sys.executable, str(fake), 'docker'], io.StringIO(), time.monotonic()+5, {'command': 3}, root)
            data = bytes(range(256))*4096
            obs = {'components': []}
            c = client.call(obs, 'import', ['import', '-', 'fixture'], data=data, need_output=True)
            out = json.loads(c['stdout'])
            self.assertEqual(out, {'args': ['docker', 'import', '-', 'fixture'], 'sha': wf.sha256_bytes(data), 'bytes': len(data)})
            self.assertTrue(c['cleanup']['clean_shutdown'])
            self.assertEqual(wf.group_members(c['pid']), ([], []))
            raw = c['raw']['stdout']
            self.assertEqual(wf.sha256_file(Path(raw['path'])), raw['sha256'])
            self.assertEqual(Path(raw['path']).read_text(), c['stdout'])

    def test_partial_output_and_nonzero_are_preserved(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            client = wf.Client([sys.executable, '-c', "import sys;print('partial');print('failure',file=sys.stderr);sys.exit(7)"], io.StringIO(), time.monotonic()+5, {'command': 3}, root)
            obs = {'components': []}
            with self.assertRaises(wf.CommandError): client.call(obs, 'bad', [])
            c = obs['components'][0]
            self.assertEqual(c['exit_code'], 7)
            self.assertIn('partial', c['stdout'])
            self.assertIn('failure', c['stderr'])
            self.assertTrue(c['cleanup']['clean_shutdown'])
            self.assertFalse(wf.component_ok(c))

    def test_timeout_reaps_actual_process(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            client = wf.Client([sys.executable, '-c', "import time;print('before timeout',flush=True);time.sleep(60)"], io.StringIO(), time.monotonic()+3, {'command': .1}, root)
            obs = {'components': []}
            with self.assertRaises(wf.CommandError): client.call(obs, 'sleep', [])
            c = obs['components'][0]
            self.assertTrue(c['timed_out'])
            self.assertIn('before timeout', c['stdout'])
            self.assertEqual(wf.group_members(c['pid']), ([], []))
            self.assertFalse(wf.component_ok(c))

    def test_failed_command_cannot_pass_without_error_annotation(self):
        obs = {'rep':0, 'components':[], 'checks':[], 'cleanup_errors':[]}
        for name in wf.REQUIRED_CHECKS['volume']: obs['checks'].append({'name':name,'ok':True})
        for stage in wf.REQUIRED_STAGES['volume']:
            obs['components'].append({'stage':stage,'status':'ok','exit_code':0,'timed_out':False})
        obs['components'][0].update(status='fail',exit_code=2)
        self.assertEqual(wf.finalize_observation(obs,'volume')['status'],'fail')

if __name__ == '__main__': unittest.main()
