from pathlib import Path
import shutil
w=Path('/root/harddind-rebuild');old=w/'workflow-owner-v1';b=w/'workflow-owner-v2';b.mkdir(exist_ok=True)
shutil.copytree(old/'repo',b/'repo',dirs_exist_ok=True)
s=(old/'supervisor.py').read_text().replace("name='wf1-'+shard", "name='wf2-'+shard")
(b/'supervisor.py').write_text(s)
p=b/'repo/scripts/run-workflow-timing.py';s=p.read_text()
pos=s.index('\ndef finalize_observation')
s=s[:pos]+'''\ndef object_missing(component):
    """Only the actual CLI no-such-object error proves removal, not any rc=1."""
    return (component_ok(component) and component.get('exit_code') == 1
            and 'no such ' in (component.get('stdout', '') + component.get('stderr', '')).lower())

'''+s[pos:]
s=s.replace("gone['exit_code'] == 1 and 'No such' in gone_text", "object_missing(gone)")
s=s.replace("if gone['exit_code'] != 1:", "if not object_missing(gone):")
s=s.replace("if probe['exit_code'] == 1:", "if object_missing(probe):")
s=s.replace("if probe['exit_code'] != 1:", "if not object_missing(probe):")
s=s.replace("c_gone['exit_code'] == 1 and v_gone['exit_code'] == 1", "object_missing(c_gone) and object_missing(v_gone)")
s=s.replace("c_gone['exit_code'] == 1 and n_gone['exit_code'] == 1", "object_missing(c_gone) and object_missing(n_gone)")
s=s.replace("if comp['timed_out']:\n            obs['cleanup_errors'].append('%s %s timed out' % (kind, args[-1]))", "if (not comp.get('cleanup', {}).get('clean_shutdown') or comp['timed_out']\n                or (comp['exit_code'] != 0 and not object_missing(comp))):\n            obs['cleanup_errors'].append('%s %s cleanup failed' % (kind, args[-1]))")
s=s.replace("    ctx.register('image', data_tag)\n", "    ctx.register('image', data_tag)\n    for suffix in ['-base', '-loaded']: ctx.register('container', container + suffix)\n")
s=s.replace("['run', '--rm', repo, 'cat',", "['run', '--rm', '--name', container + '-base', *ctx.labels('image'), repo, 'cat',")
s=s.replace("['run', '--rm', data_tag, 'sh',", "['run', '--rm', '--name', container + '-loaded', *ctx.labels('image'), data_tag, 'sh',")
s=s.replace("    ctx.register('image', warm_tag)\n", "    ctx.register('image', warm_tag)\n    ctx.register('container', cold_tag + '-run')\n    ctx.register('container', warm_tag + '-run')\n")
s=s.replace("['run', '--rm', cold_tag]", "['run', '--rm', '--name', cold_tag + '-run', *ctx.labels('build'), cold_tag]")
s=s.replace("['run', '--rm', warm_tag]", "['run', '--rm', '--name', warm_tag + '-run', *ctx.labels('build'), warm_tag]")
s=s.replace("    dns_addresses = None", "    expected_ip = ctx.run('server_ip', ['inspect', '-f', '{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}', srv], need_output=True)['stdout'].strip()\n    dns_addresses = None")
s=s.replace("    for attempt in range(3):\n        probe = ctx.run('dns_try%d'", "    for attempt in range(3):\n        client_name = srv + '-dns-' + str(attempt)\n        ctx.register('container', client_name)\n        probe = ctx.run('dns_try%d'")
s=s.replace("['run', '--rm', '--network', netname, base_tag,\n                                                'nslookup', srv]", "['run', '--rm', '--name', client_name, *ctx.labels('net'), '--network', netname, base_tag,\n                                                'nslookup', srv]")
s=s.replace("dns_addresses = parse_nslookup(probe['stdout'], srv)", "dns_addresses = parse_nslookup(probe['stdout'], srv) if component_ok(probe) else None")
s=s.replace("ctx.check('dns_resolved', bool(dns_addresses), dns_addresses)", "ctx.check('dns_resolved', bool(dns_addresses) and expected_ip in dns_addresses, {'expected': expected_ip, 'resolved': dns_addresses})")
s=s.replace("    for attempt in range(6):\n        probe = ctx.run('http_try%d'", "    for attempt in range(6):\n        client_name = srv + '-http-' + str(attempt)\n        ctx.register('container', client_name)\n        probe = ctx.run('http_try%d'")
s=s.replace("['run', '--rm', '--network', netname, base_tag, 'sh',", "['run', '--rm', '--name', client_name, *ctx.labels('net'), '--network', netname, base_tag, 'sh',")
# Any command timeout remains a failed observation even when a later retry succeeds.
s=s.replace("if obs.get('error') or hard_failures or obs.get('cleanup_errors'):", "if obs.get('error') or hard_failures or obs.get('cleanup_errors') or any(c.get('timed_out') for c in obs['components']):")
# Keep per-component retries visible instead of silently folding them into a pass.
s=s.replace("            for check in obs.get('checks', []):", "            for comp in obs['components']:\n                if comp.get('status') in ('fail', 'timeout'):\n                    problems.append({'workflow': name, 'rep': obs['rep'], 'kind': 'component_failure',\n                                     'detail': comp['stage'], 'tolerated_retry': comp.get('tolerated', False),\n                                     'exit_code': comp.get('exit_code'), 'timed_out': comp.get('timed_out')})\n            for check in obs.get('checks', []):")
compile(s,str(p),'exec');p.write_text(s)
p=b/'repo/tests/test_workflow_transport.py';s=p.read_text();s=s.replace("    def test_failed_command_cannot_pass_without_error_annotation", "    def test_real_lowercase_removal_error(self):\n        c = {'status': 'ok', 'exit_code': 1, 'expect': [1], 'stderr': 'error: no such object: fixture', 'stdout': '[]'}\n        self.assertTrue(wf.object_missing(c))\n        c['stderr'] = 'Cannot connect to the Docker daemon'\n        self.assertFalse(wf.object_missing(c))\n        c['stderr'] = 'No such object: fixture'\n        c['timed_out'] = True\n        self.assertFalse(wf.object_missing(c))\n\n    def test_failed_command_cannot_pass_without_error_annotation")
p.write_text(s)
print(b)
