from pathlib import Path
b=Path('/root/harddind-rebuild/workflow-owner-v1/repo')
p=b/'scripts/run-workflow-timing.py';s=p.read_text()
def rep(a,z):
 global s
 assert a in s,a
 s=s.replace(a,z)
rep('import harddind  # noqa: E402','import harddind  # noqa: E402\nfrom guest_cleanup import cleanup_group, group_members')
rep("    if obs.get('error'):\n", "    if obs.get('error') or hard_failures or obs.get('cleanup_errors'):\n")
rep("    if comp.get('status') != 'ok' or comp.get('timed_out'):", "    if comp.get('status') != 'ok' or comp.get('timed_out') or not comp.get('cleanup', {}).get('clean_shutdown', True):")
rep("    expected = set(report.get('shards', ()))", "    if (report.get('runner_error') or report.get('setup', {}).get('error')\n            or report.get('aborted') or report.get('leftovers', {}).get('scan_failed')\n            or report.get('inputs_unchanged') is not True):\n        return False\n    expected = set(report.get('shards', ()))\n    if not expected or not 1 <= report.get('reps_requested', 0) <= 10:\n        return False")
rep("        if len(obs_list) < report.get('reps_requested', 0):", "        if len(obs_list) != report['reps_requested'] or sorted(o['rep'] for o in obs_list) != list(range(report['reps_requested'])):")
rep("not obs.get('reaped_cleanly', True)", "not obs.get('reaped_cleanly', False)")
rep("def __init__(self, base, log, deadline, timeouts):", "def __init__(self, base, log, deadline, timeouts, rawdir):")
rep("        self.timeouts = timeouts\n", "        self.timeouts = timeouts\n        self.rawdir = rawdir\n        self.sequence = 0\n")
rep("        out, err = proc.communicate()", "        out, err = proc.communicate(timeout=10)")
rep("    def _popen(self, cmd):\n        proc = subprocess.Popen(cmd, stdin=subprocess.DEVNULL", "    def _popen(self, cmd, data=None):\n        proc = subprocess.Popen(cmd, stdin=subprocess.PIPE if data is not None else subprocess.DEVNULL")
rep("        stdout = out.decode(errors='replace')", "        self.sequence += 1\n        raw = {}\n        for channel, payload in [('stdout', out), ('stderr', err)]:\n            path = self.rawdir / ('%04d-%s.%s' % (self.sequence, stage, channel))\n            with path.open('xb') as f: f.write(payload)\n            raw[channel] = {'path': str(path), 'sha256': sha256_bytes(payload), 'bytes': len(payload)}\n        stdout = out.decode(errors='replace')")
rep("'overlaps': list(overlaps)}\n        self.log", "'overlaps': list(overlaps), 'raw': raw}\n        self.log")
rep("            proc = self._popen(cmd)", "            proc = self._popen(cmd, data)")
rep("        finally:\n            if proc is not None:\n                CURRENT_PROCS.discard(proc)\n        comp = self.component", "        finally:\n            elapsed = time.monotonic() - started\n            audit = None\n            if proc is not None:\n                if proc.poll() is None:\n                    self._kill(proc)\n                audit = cleanup_group(proc.pid)\n                CURRENT_PROCS.discard(proc)\n        comp = self.component")
rep("        obs['components'].append(comp)\n        if not tolerate", "        comp['seconds'] = elapsed\n        comp['pid'] = proc.pid\n        comp['cleanup'] = audit\n        obs['components'].append(comp)\n        if not tolerate")
rep("        finally:\n            CURRENT_PROCS.discard(proc)", "        finally:\n            if proc.poll() is None:\n                self._kill(proc)\n            proc._harddind_cleanup = cleanup_group(proc.pid)\n            CURRENT_PROCS.discard(proc)")
rep("    ctx.obs['components'].append(wait_comp)", "    wait_comp['pid'] = waiter.pid\n    wait_comp['cleanup'] = waiter._harddind_cleanup\n    ctx.obs['components'].append(wait_comp)")
rep("http://%s/", "http://%s:8080/")
rep("'--network', 'none', *ctx.labels('volume'),", "*ctx.labels('volume'),")
rep("            client = Client(base_cmd, log, deadline, timeouts)", "            client = Client(base_cmd + ['docker'], log, deadline, timeouts, rawdir)")
rep("'--filter', names['label']", "'--filter', 'label=' + names['label']")
rep("    build_lock = (work / 'kernel-build.lock').open('a')\n    fcntl.flock(build_lock, fcntl.LOCK_SH)", "    build_lock = (work / 'kernel-build.lock').open('a')\n    lock_deadline = time.monotonic() + 90\n    while True:\n        try:\n            fcntl.flock(build_lock, fcntl.LOCK_SH | fcntl.LOCK_NB)\n            break\n        except BlockingIOError:\n            if time.monotonic() >= lock_deadline: raise RuntimeError('build lock wait exceeded 90 seconds')\n            time.sleep(.1)")
rep("    if not 1 <= a.reps <= 10:", "    import math\n    for key, value in vars(a).items():\n        if key.endswith('_timeout') or key == 'workload_budget':\n            if not math.isfinite(value) or value <= 0:\n                p.error(key + ' must be finite and positive')\n    if not 1 <= a.reps <= 10:")
# Preserve and bound outstanding wait clients even if stop fails or budget expires.
rep("        cleanup_started = time.monotonic()\n        try:", "        cleanup_started = time.monotonic()\n        for proc in list(CURRENT_PROCS):\n            if proc.poll() is None: client._kill(proc)\n            audit = cleanup_group(proc.pid)\n            obs.setdefault('orphan_clients', []).append(audit)\n            obs['cleanup_errors'].append('unfinished client process group %d' % proc.pid)\n            CURRENT_PROCS.discard(proc)\n        try:")
# Host commands must also be reaped on external interruption.
a=s.index('    timed_out = False\n',s.index('def host_command'));z=s.index('\n    text = out.decode',a)
s=s[:a]+'''    timed_out = False
    CURRENT_PROCS.add(proc)
    try:
        out = proc.communicate(timeout=timeout)[0]
        rc = proc.returncode
    except subprocess.TimeoutExpired:
        timed_out = True
        out, _, rc = Client._kill(proc)
    finally:
        elapsed = time.monotonic() - started
        if proc.poll() is None: Client._kill(proc)
        audit = cleanup_group(proc.pid)
        CURRENT_PROCS.discard(proc)
'''+s[z:]
rep("'seconds': time.monotonic() - started, 'output': text[-OUTPUT_CAP:]}", "'seconds': elapsed, 'output': text[-OUTPUT_CAP:], 'pid': proc.pid, 'cleanup': audit}")
rep("and not state.get('forced_shutdown')),", "and state.get('network_cleanup', {}).get('clean_shutdown')\n                    and state.get('guest_exit_code') == 0 and state.get('network_exit_code') == 0\n                    and stop['exit_code'] == 0 and not stop['timed_out']\n                    and stop['cleanup']['clean_shutdown']\n                    and not state.get('forced_shutdown')), ")
rep("               repo / 'sources.lock.json']", "               repo / 'scripts/guest_cleanup.py', repo / 'scripts/port_driver.py', repo / 'sources.lock.json']")
rep("    report['raw_dir'] = str(rawdir)", "    report['raw_dir'] = str(rawdir)\n    input_paths = [kernel, disk, pathlib.Path(rootfs_info['path']),\n                   work / 'network-backend', work / 'client/docker',\n                   work / 'client/ld-musl-x86_64.so.1',\n                   *(repo / n for n in report['inputs']['sources'])]\n    plugin = work / 'client/cli-plugins/docker-buildx'\n    if 'build' in a.shards: input_paths.append(plugin)\n    report['input_hashes_before'] = {str(f): harddind.sha(f) for f in input_paths}")
rep("        report['total_wall_seconds'] = time.monotonic() - wall_started", "        report['input_hashes_after'] = {str(f): harddind.sha(f) if f.is_file() else None for f in input_paths}\n        report['inputs_unchanged'] = report['input_hashes_before'] == report['input_hashes_after']\n        report['total_wall_seconds'] = time.monotonic() - wall_started")
rep("    disk = (a.disk or work / 'runtime.ext4').resolve()", "    disk = a.disk.resolve()")
rep("p.add_argument('--disk', type=pathlib.Path)", "p.add_argument('--disk', type=pathlib.Path, required=True)")
compile(s,str(p),'exec');p.write_text(s)
p=b/'scripts/analyze-workflow-timing.py';s=p.read_text()
a=s.index('    return {key:',s.index('def fixed_inputs'));z=s.index('\n\n\ndef compare',a)
s=s[:a]+'''    return {'inputs': {key: {k: v for k, v in inputs.get(key, {}).items() if k not in ('data', 'path')}
                       for key in FIXED_INPUT_KEYS},
            'sources': inputs.get('sources'), 'config': report.get('config'),
            'cpu_affinity': report.get('host', {}).get('cpu_affinity'),
            'server_version': report.get('server_version')}
'''+s[z:]
s=s.replace("                bucket['observation_body_seconds'].append(obs.get('body_seconds', 0.0))", "                if obs['status'] != 'not_run_wall_budget':\n                    bucket['observation_body_seconds'].append(obs['body_seconds'])")
s=s.replace("'min_seconds': min(bodies),", "'min_seconds': min(bodies) if bodies else None,").replace("'max_seconds': max(bodies)}", "'max_seconds': max(bodies) if bodies else None}")
s=s.replace("    baseline = reports[0]", "    if not reports: raise ValueError('no reports')\n    baseline = reports[0]")
s=s.replace("    return 0\n", "    return 0 if result['fixed_inputs_match_except_kernel'] else 1\n")
compile(s,str(p),'exec');p.write_text(s)
print('owner transport, verdict, cleanup, input identity and network fixes applied')
