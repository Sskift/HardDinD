from pathlib import Path
import shutil
w=Path('/root/harddind-rebuild');old=w/'workflow-owner-v4';b=w/'workflow-owner-v5';b.mkdir(exist_ok=False)
shutil.copytree(old/'repo',b/'repo')
(b/'supervisor.py').write_text((old/'supervisor.py').read_text().replace("name='wf4-'+shard","name='wf5-'+shard"))
p=b/'repo/scripts/run-workflow-timing.py';s=p.read_text()
a=s.index('    return (component_ok(component)',s.index('def object_missing'));z=s.index('\n\n',a)
s=s[:a]+'''    if not component_ok(component) or component.get('exit_code') != 1:
        return False
    message = (component.get('stdout', '') + component.get('stderr', '')).lower()
    return ('no such ' in message
            or re.search(r'(?m)^error response from daemon: network [a-z0-9_.-]+ not found$', message) is not None)
'''+s[z:]
p.write_text(s)
p=b/'repo/tests/test_workflow_transport.py';s=p.read_text();needle='    def test_real_lowercase_removal_error(self):'
s=s.replace(needle,'''    def test_real_network_missing_response(self):
        c = {'status':'ok','exit_code':1,'expect':[1], 'stdout':'[]\\n',
             'stderr':'Error response from daemon: network harddind-wf-wf4-net-net0 not found\\n'}
        self.assertTrue(wf.object_missing(c))
        c['stderr'] += 'exit status 1\\n'
        self.assertTrue(wf.object_missing(c))
        c['stderr'] = 'Error response from daemon: network harddind-wf-wf4-net-net0 has active endpoints\\n'
        self.assertFalse(wf.object_missing(c))

'''+needle);p.write_text(s)
print(b)
