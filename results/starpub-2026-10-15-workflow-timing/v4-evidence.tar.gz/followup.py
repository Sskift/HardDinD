from pathlib import Path
import subprocess,json,time,datetime,tarfile,hashlib,os,sys
b=Path(__file__).resolve().parent;w=b.parent;prior=w/'workflow-owner-v3'
sys.dont_write_bytecode=True;sys.path.insert(0,str(b/'repo/scripts'))
from guest_cleanup import cleanup_group
r={'status':'waiting-for-build'}
def save():(b/'followup-status.json').write_text(json.dumps(r,indent=2)+'\n')
save();end=time.monotonic()+900
while True:
    s=json.loads((prior/'followup-status.json').read_text())
    if s['status']=='finished':break
    if time.monotonic()>end:raise TimeoutError('build wait exceeded 900 seconds')
    time.sleep(2)
c=json.loads((prior/'wf3-build-status.json').read_text());assert c['groups_empty'],c
r['status']='fixture-check';save()
rootfs=w/'cache/alpine-minirootfs-3.24.2-x86_64.tar.gz'
with tarfile.open(rootfs) as t:
    names=[n for n in t.getnames() if n.lstrip('./')=='bin/busybox'];assert len(names)==1
    data=t.extractfile(names[0]).read()
probe=b/'pinned-busybox';probe.write_bytes(data);probe.chmod(0o500)
r['busybox_sha256']=hashlib.sha256(data).hexdigest();r['commands']=[]
for label,args in [('applets',['--list']),('httpd-help',['httpd','--help']),('nc-help',['nc','--help'])]:
    cmd=[str(w/'client/ld-musl-x86_64.so.1'),str(probe),*args]
    with (b/(label+'.stdout')).open('xb') as so,(b/(label+'.stderr')).open('xb') as se:
        p=subprocess.Popen(cmd,stdin=subprocess.DEVNULL,stdout=so,stderr=se,start_new_session=True)
        rc=p.wait(10)
    r['commands'].append({'command':cmd,'exit_code':rc,'cleanup':cleanup_group(p.pid)})
    save()
r['status']='testing';save()
with (b/'unit.stdout').open('xb') as so,(b/'unit.stderr').open('xb') as se:
    test=subprocess.run(['python3','-B','-m','unittest','discover','-s','tests','-p','test_workflow*.py'],cwd=b/'repo',stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=30)
r['unit_exit']=test.returncode;save()
if test.returncode==0:
    r['status']='net-workflow';save()
    with (b/'wf4-net-supervisor.log').open('x') as log:
        p=subprocess.Popen(['python3',str(b/'supervisor.py'),'net'],stdin=subprocess.DEVNULL,stdout=log,stderr=log)
        r['pid']=p.pid;save();r['runner_exit']=p.wait()
r.update(status='finished',finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
